# Portfolio email OTP integration (Supabase)

This package updates the supplied portfolio HTML to use Supabase email OTP and a Supabase Edge Function for sending verified contact messages through Resend. It removes the direct Web3Forms submission path.

## 1. Create/configure Supabase
1. Create a Supabase project.
2. In Authentication → Providers → Email, enable email authentication and email OTP.
3. In Authentication → URL Configuration, add your production website URL and local development URL.
4. In Authentication → Email Templates, make sure the email template includes `{{ .Token }}` so the visitor receives the six-digit code.
5. Configure custom SMTP for production delivery. The default Supabase email sender is intended for testing and has sending restrictions.
6. Copy the Project URL and publishable key (or legacy anon key). Put these in the two constants near the top of the HTML script. Never use the service_role/secret key in HTML.

## 2. Configure Resend
1. Create a Resend account and verify a domain you control.
2. Create an API key.
3. Choose a sender address on that verified domain, e.g. `Portfolio <contact@yourdomain.com>`.

## 3. Deploy the Edge Function
Install the Supabase CLI and sign in, then from this folder:

```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase secrets set RESEND_API_KEY=re_xxx CONTACT_TO_EMAIL=your-inbox@gmail.com CONTACT_FROM_EMAIL='Portfolio <contact@yourdomain.com>' ALLOWED_ORIGIN=https://yourdomain.com
supabase functions deploy send-contact
```

The function uses the caller's Supabase access token and checks that the authenticated user's email is confirmed and matches the submitted sender email. Keep JWT verification enabled for this function (the default). Never disable `verify_jwt`.

For local testing, set `ALLOWED_ORIGIN` to your local origin (e.g. `http://localhost:5500`) or temporarily use `*` only during development. Set the production origin before launch.

## 4. Publish the website
Upload `prashant_portfolio_supabase_otp.html` as your site's `index.html` after adding the Supabase URL and publishable key. Test with an email inbox you control. Confirm the OTP email arrives, verify it, submit a message, and check the destination inbox.

## Important notes
- Supabase `signInWithOtp` creates an Auth user for new visitor email addresses (`shouldCreateUser: true`). This is the chosen no-custom-OTP-storage approach. If you do not want visitor accounts, use a custom server-side OTP flow instead.
- This implementation requires a working Supabase SMTP configuration and a verified Resend sending domain.
- Basic frontend checks are for usability only. The Edge Function independently checks the authenticated, confirmed email before sending.
- Add production rate limits/abuse monitoring for the Edge Function and configure appropriate Supabase Auth rate limits. Consider CAPTCHA if the endpoint is abused.
- Never commit API keys or service-role keys to the HTML file or public repository.
